package game;

public class Player {
    public String name;
    public int XP;
    public boolean writOfAres;
    public boolean writOfAceso;
    public boolean writOfProteus;

    public Player() {
        this.name = "";
        this.XP = 0;
        this.writOfAres = false;
        this.writOfAceso = false;
        this.writOfProteus = false;
    }
}
